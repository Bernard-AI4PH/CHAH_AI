#!/bin/bash

# CHAH Flutter App Setup Script
# This script helps you set up the Flutter project quickly

echo "======================================"
echo "CHAH AI Care Flutter App Setup"
echo "======================================"
echo ""

# Check if Flutter is installed
if ! command -v flutter &> /dev/null
then
    echo "❌ Flutter is not installed!"
    echo "Please install Flutter from: https://docs.flutter.dev/get-started/install"
    exit 1
else
    echo "✅ Flutter is installed"
    flutter --version
fi

echo ""
echo "======================================"
echo "Step 1: Installing Dependencies"
echo "======================================"
flutter pub get

echo ""
echo "======================================"
echo "Step 2: Checking Flutter Doctor"
echo "======================================"
flutter doctor

echo ""
echo "======================================"
echo "Step 3: Configuration"
echo "======================================"
echo ""
echo "Please configure your API endpoint in:"
echo "lib/utils/constants.dart"
echo ""
echo "Options:"
echo "  - Android Emulator: http://10.0.2.2:5000"
echo "  - iOS Simulator: http://localhost:5000"
echo "  - Physical Device: http://YOUR_IP:5000"
echo ""
read -p "Have you configured the API URL? (y/n): " configured

if [ "$configured" != "y" ]; then
    echo ""
    echo "Please edit lib/utils/constants.dart before running the app"
    echo "Then run: flutter run"
    exit 0
fi

echo ""
echo "======================================"
echo "Step 4: Select Run Option"
echo "======================================"
echo "1) Run on connected device"
echo "2) Build APK for Android"
echo "3) Build for iOS (macOS only)"
echo "4) Exit"
echo ""
read -p "Enter your choice (1-4): " choice

case $choice in
    1)
        echo ""
        echo "Available devices:"
        flutter devices
        echo ""
        echo "Starting app..."
        flutter run
        ;;
    2)
        echo ""
        echo "Building APK..."
        flutter build apk --release
        echo ""
        echo "✅ APK built successfully!"
        echo "Location: build/app/outputs/flutter-apk/app-release.apk"
        ;;
    3)
        echo ""
        echo "Building for iOS..."
        flutter build ios --release
        echo ""
        echo "✅ iOS build complete!"
        ;;
    4)
        echo "Setup complete. Run 'flutter run' when ready."
        exit 0
        ;;
    *)
        echo "Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "======================================"
echo "Setup Complete!"
echo "======================================"
echo ""
echo "Next steps:"
echo "1. Ensure your Flask backend is running"
echo "2. Test the app with patient ID: P001"
echo "3. Check API_SETUP_GUIDE.md for troubleshooting"
echo ""
