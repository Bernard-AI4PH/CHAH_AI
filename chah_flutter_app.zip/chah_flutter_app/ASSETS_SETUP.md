# IMPORTANT: Assets Setup

## Logo/Favicon Setup Required

The Flutter app expects a logo file at: `assets/images/logo.png`

### Steps to Add Your Logo:

1. **Copy your favicon.png** to the assets directory:
   ```bash
   cp favicon.png chah_flutter_app/assets/images/logo.png
   ```

2. **For App Icon** (launcher icon on device home screen):
   
   **Android:**
   - Place different sizes in `android/app/src/main/res/`
     - mipmap-mdpi (48x48)
     - mipmap-hdpi (72x72)
     - mipmap-xhdpi (96x96)
     - mipmap-xxhdpi (144x144)
     - mipmap-xxxhdpi (192x192)
   
   **iOS:**
   - Use Xcode Asset Catalog: `ios/Runner/Assets.xcassets/AppIcon.appiconset/`
   - Requires multiple sizes

   **Easy Way - Use flutter_launcher_icons package:**
   
   Add to `pubspec.yaml`:
   ```yaml
   dev_dependencies:
     flutter_launcher_icons: ^0.13.1
   
   flutter_launcher_icons:
     android: true
     ios: true
     image_path: "assets/images/logo.png"
   ```
   
   Then run:
   ```bash
   flutter pub get
   flutter pub run flutter_launcher_icons
   ```

## Current Assets Directory Structure

```
assets/
├── images/
│   └── logo.png          # ← ADD YOUR LOGO HERE
├── animations/           # Optional: for Lottie animations
└── icons/               # Optional: for custom icons
```

## Assets Included in pubspec.yaml

The `pubspec.yaml` already declares these asset directories:
```yaml
flutter:
  assets:
    - assets/images/
    - assets/animations/
    - assets/icons/
```

Any files you add to these directories will be automatically included in the app bundle.

## Recommended Image Sizes

### Logo for In-App Display
- **Format**: PNG with transparency
- **Size**: 512x512 or larger
- **Max file size**: < 1MB

### App Launcher Icon
- **Format**: PNG
- **Size**: 1024x1024 (will be scaled down)
- **Design**: Simple, recognizable at small sizes
- **Background**: Solid color or transparent

## Using the Logo in Code

The logo is already referenced in the code, but you can use it anywhere:

```dart
Image.asset(
  'assets/images/logo.png',
  width: 200,
  height: 100,
)
```

## Alternative: Use Package Icon

If you don't have a logo ready, you can temporarily use Material Icons:

In `lib/screens/home_screen.dart`, find this section:
```dart
Container(
  padding: const EdgeInsets.all(12),
  decoration: BoxDecoration(
    color: const Color(0xFF6BA539).withOpacity(0.1),
    borderRadius: BorderRadius.circular(12),
  ),
  child: Icon(
    Icons.medical_information_rounded,
    size: 32,
    color: const Color(0xFF6BA539),
  ),
),
```

This already provides a nice medical icon. You can keep this for now until you add your logo.

## Next Steps

1. Add your logo to `assets/images/logo.png`
2. (Optional) Generate app icons using flutter_launcher_icons
3. Run the app: `flutter run`

## Troubleshooting

**"Unable to load asset"**
- Ensure file is in correct location
- Run `flutter clean` and `flutter pub get`
- Check file name matches exactly (case-sensitive)

**Icon looks blurry**
- Use higher resolution image
- Ensure PNG is not compressed
- Try SVG if possible (requires flutter_svg package)

**App icon not updating**
- Run `flutter clean`
- Delete and reinstall app
- For iOS: Clean build folder in Xcode
