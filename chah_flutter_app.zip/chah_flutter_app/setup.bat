@echo off
echo ======================================
echo CHAH AI Care Flutter App Setup
echo ======================================
echo.

REM Check if Flutter is installed
where flutter >nul 2>nul
if %errorlevel% neq 0 (
    echo X Flutter is not installed!
    echo Please install Flutter from: https://docs.flutter.dev/get-started/install
    pause
    exit /b 1
) else (
    echo √ Flutter is installed
    flutter --version
)

echo.
echo ======================================
echo Step 1: Installing Dependencies
echo ======================================
call flutter pub get

echo.
echo ======================================
echo Step 2: Checking Flutter Doctor
echo ======================================
call flutter doctor

echo.
echo ======================================
echo Step 3: Configuration
echo ======================================
echo.
echo Please configure your API endpoint in:
echo lib\utils\constants.dart
echo.
echo Options:
echo   - Android Emulator: http://10.0.2.2:5000
echo   - iOS Simulator: http://localhost:5000
echo   - Physical Device: http://YOUR_IP:5000
echo.
set /p configured="Have you configured the API URL? (y/n): "

if /i not "%configured%"=="y" (
    echo.
    echo Please edit lib\utils\constants.dart before running the app
    echo Then run: flutter run
    pause
    exit /b 0
)

echo.
echo ======================================
echo Step 4: Select Run Option
echo ======================================
echo 1) Run on connected device
echo 2) Build APK for Android
echo 3) Exit
echo.
set /p choice="Enter your choice (1-3): "

if "%choice%"=="1" (
    echo.
    echo Available devices:
    call flutter devices
    echo.
    echo Starting app...
    call flutter run
) else if "%choice%"=="2" (
    echo.
    echo Building APK...
    call flutter build apk --release
    echo.
    echo √ APK built successfully!
    echo Location: build\app\outputs\flutter-apk\app-release.apk
) else if "%choice%"=="3" (
    echo Setup complete. Run 'flutter run' when ready.
    exit /b 0
) else (
    echo Invalid choice
    pause
    exit /b 1
)

echo.
echo ======================================
echo Setup Complete!
echo ======================================
echo.
echo Next steps:
echo 1. Ensure your Flask backend is running
echo 2. Test the app with patient ID: P001
echo 3. Check API_SETUP_GUIDE.md for troubleshooting
echo.
pause
