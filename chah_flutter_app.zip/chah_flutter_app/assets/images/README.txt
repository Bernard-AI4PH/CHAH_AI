PLACE YOUR LOGO HERE
====================

File name: logo.png
Recommended size: 512x512 or larger
Format: PNG with transparency

You can copy your favicon.png file here:
cp favicon.png assets/images/logo.png

This will be used for in-app logo display.

For the app launcher icon (home screen icon), follow the instructions in ASSETS_SETUP.md
