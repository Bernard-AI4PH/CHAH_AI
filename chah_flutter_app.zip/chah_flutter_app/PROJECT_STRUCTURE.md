# Project Structure

Complete overview of the CHAH Flutter App project structure.

## 📁 Root Directory

```
chah_flutter_app/
├── 📄 README.md                    # Main documentation
├── 📄 QUICKSTART.md                # 5-minute setup guide
├── 📄 API_SETUP_GUIDE.md           # API connection guide
├── 📄 DEPLOYMENT_GUIDE.md          # Production deployment guide
├── 📄 TESTING_CHECKLIST.md         # Complete testing checklist
├── 📄 PROJECT_STRUCTURE.md         # This file
├── 📄 pubspec.yaml                 # Flutter dependencies
├── 📄 analysis_options.yaml        # Dart linter configuration
├── 📄 .gitignore                   # Git ignore rules
├── 🔧 setup.sh                     # Linux/macOS setup script
├── 🔧 setup.bat                    # Windows setup script
│
├── 📁 lib/                         # Main application code
├── 📁 android/                     # Android-specific files
├── 📁 ios/                         # iOS-specific files
└── 📁 assets/                      # Images, fonts, etc.
```

---

## 📱 lib/ - Application Code

The heart of your Flutter application.

```
lib/
├── 📄 main.dart                    # App entry point
│
├── 📁 models/                      # Data models
│   └── patient.dart                # Patient data structure
│
├── 📁 screens/                     # UI Screens
│   ├── home_screen.dart            # Main screen with input
│   └── pdf_viewer_screen.dart      # PDF viewing screen
│
├── 📁 services/                    # Business logic & API
│   └── report_service.dart         # API calls & PDF handling
│
├── 📁 utils/                       # Utilities & constants
│   └── constants.dart              # App constants & API config
│
└── 📁 widgets/                     # Reusable UI components
    ├── patient_id_input.dart       # Custom input field
    ├── quick_access_card.dart      # Quick select buttons
    └── info_card.dart              # Information cards
```

### 📄 Key Files Explained

#### `main.dart`
- App initialization
- Theme configuration
- Route setup
- Provider configuration

#### `models/patient.dart`
- Patient data structure
- JSON serialization
- Data validation

#### `screens/home_screen.dart`
- Main user interface
- Patient ID input
- Quick access buttons
- Info cards

#### `screens/pdf_viewer_screen.dart`
- PDF display
- Print functionality
- Save functionality
- Share functionality

#### `services/report_service.dart`
- API communication
- PDF byte handling
- Error management
- State management

#### `utils/constants.dart`
- API configuration
- App constants
- Error messages
- Sample data

#### `widgets/`
- Reusable UI components
- Custom styled widgets
- Consistent design elements

---

## 🤖 android/ - Android Configuration

```
android/
├── 📁 app/
│   ├── 📄 build.gradle             # App-level Gradle config
│   └── 📁 src/main/
│       ├── AndroidManifest.xml     # App permissions & config
│       └── 📁 kotlin/
│           └── MainActivity.kt     # Main Android activity
│
└── 📄 build.gradle                 # Project-level Gradle config
```

### Important Android Files

#### `AndroidManifest.xml`
Defines:
- App permissions (Internet, Storage)
- App name and icon
- Network security config
- Activity configurations

#### `build.gradle` (app-level)
Configures:
- Application ID
- SDK versions
- Build types
- Signing configs

---

## 🍎 ios/ - iOS Configuration

```
ios/
├── 📁 Runner/
│   ├── Info.plist                  # iOS app configuration
│   ├── AppDelegate.swift           # iOS app delegate
│   └── Assets.xcassets/            # App icons & launch images
│
└── Runner.xcworkspace              # Xcode workspace
```

### Important iOS Files

#### `Info.plist`
Defines:
- App permissions
- Privacy usage descriptions
- URL schemes
- Supported orientations

---

## 🎨 assets/ - Resources

```
assets/
├── 📁 images/
│   └── logo.png                    # App logo (your favicon.png)
│
├── 📁 animations/                  # Lottie animations (optional)
│
└── 📁 icons/                       # Custom icons (optional)
```

### Asset Guidelines

**Images:**
- PNG format preferred
- Multiple resolutions for different screen densities
- Optimize file sizes

**Icons:**
- SVG or PNG format
- Consistent style
- Proper sizing

---

## 📄 Configuration Files

### `pubspec.yaml`
**Purpose**: Flutter project configuration

**Contains:**
- Project metadata (name, version)
- Dependencies (packages)
- Asset declarations
- Flutter SDK version

**Key Dependencies:**
```yaml
dependencies:
  flutter:
    sdk: flutter
  provider: ^6.1.1        # State management
  dio: ^5.4.0             # HTTP client
  printing: ^5.11.1       # PDF handling
  google_fonts: ^6.1.0    # Custom fonts
  share_plus: ^7.2.1      # Sharing functionality
```

### `analysis_options.yaml`
**Purpose**: Dart code linting rules

**Enforces:**
- Code style consistency
- Best practices
- Common error prevention

### `.gitignore`
**Purpose**: Excludes files from Git

**Ignores:**
- Build outputs
- IDE configurations
- Generated files
- Sensitive data

---

## 🚀 Scripts

### `setup.sh` (Linux/macOS)
Automated setup script that:
1. Checks Flutter installation
2. Installs dependencies
3. Runs Flutter doctor
4. Helps configure API
5. Provides run options

### `setup.bat` (Windows)
Windows equivalent of setup.sh with same functionality.

---

## 📚 Documentation Files

### `README.md`
Main documentation covering:
- Features overview
- Installation instructions
- Configuration guide
- Running the app
- Building for production

### `QUICKSTART.md`
Fast 5-minute setup guide for:
- Immediate setup
- First run
- Quick troubleshooting
- Common commands

### `API_SETUP_GUIDE.md`
Detailed API connection guide:
- Finding your IP address
- Configuring for different environments
- Backend requirements
- Firewall setup
- Troubleshooting connections

### `DEPLOYMENT_GUIDE.md`
Production deployment guide:
- Backend deployment
- Android Play Store deployment
- iOS App Store deployment
- Post-deployment monitoring
- Security best practices

### `TESTING_CHECKLIST.md`
Comprehensive testing checklist:
- UI testing
- Functionality testing
- Platform-specific testing
- Performance testing
- Security testing

---

## 🔧 Development Workflow

### 1. Setup
```bash
flutter pub get
```

### 2. Development
```bash
flutter run
```

### 3. Testing
```bash
flutter test
```

### 4. Building
```bash
# Android
flutter build apk --release

# iOS
flutter build ios --release
```

---

## 📝 Adding New Features

### New Screen
1. Create file in `lib/screens/`
2. Add route in `main.dart`
3. Implement UI and logic
4. Update navigation

### New Widget
1. Create file in `lib/widgets/`
2. Make widget reusable
3. Use consistent styling
4. Document parameters

### New Service
1. Create file in `lib/services/`
2. Implement as ChangeNotifier
3. Add to providers in main.dart
4. Handle errors properly

### New Model
1. Create file in `lib/models/`
2. Add JSON serialization
3. Include validation
4. Document properties

---

## 🎨 Customization

### Changing Colors
Edit `lib/main.dart`:
```dart
colorScheme: ColorScheme.fromSeed(
  seedColor: Color(0xFF6BA539), // Your brand color
)
```

### Changing App Name
Edit `pubspec.yaml`:
```yaml
name: your_app_name
```

And `AndroidManifest.xml`:
```xml
android:label="Your App Name"
```

### Adding Assets
1. Add file to assets directory
2. Declare in `pubspec.yaml`:
```yaml
flutter:
  assets:
    - assets/images/your_image.png
```

### Changing Fonts
1. Add font files to assets
2. Declare in `pubspec.yaml`
3. Use in theme or individual widgets

---

## 🐛 Debugging

### View Logs
```bash
flutter logs
```

### Debug Mode
```bash
flutter run --debug
```

### Profile Mode
```bash
flutter run --profile
```

### Analyze Code
```bash
flutter analyze
```

---

## 📊 Performance

### Key Metrics to Monitor
- App size
- Memory usage
- Load times
- Frame rate (60 fps target)
- API response times

### Optimization Tips
- Use const constructors
- Minimize rebuilds
- Lazy load data
- Optimize images
- Profile regularly

---

## 🔒 Security

### Best Practices
- Never commit API keys
- Use HTTPS in production
- Validate all inputs
- Handle errors securely
- Follow HIPAA guidelines

### Sensitive Files
These should NEVER be committed:
- `android/key.properties`
- `.env` files
- API keys
- Passwords

---

## 📱 Platform Differences

### Android
- Material Design
- Back button behavior
- File system access
- Permissions model

### iOS
- Cupertino widgets available
- Gesture navigation
- Different file system
- Privacy requirements

---

## 🆘 Getting Help

### Resources
1. Flutter Docs: https://docs.flutter.dev
2. Dart Docs: https://dart.dev
3. Stack Overflow: flutter tag
4. GitHub Issues
5. Project documentation files

### Common Issues
See `API_SETUP_GUIDE.md` for:
- Connection problems
- Build errors
- Runtime errors
- Platform-specific issues

---

## ✅ Maintenance

### Regular Tasks
- Update dependencies: `flutter pub upgrade`
- Update Flutter: `flutter upgrade`
- Clean builds: `flutter clean`
- Analyze code: `flutter analyze`
- Run tests: `flutter test`

### Dependency Updates
Check for updates:
```bash
flutter pub outdated
```

Update all:
```bash
flutter pub upgrade
```

---

## 🎯 Best Practices

### Code Organization
- One widget per file
- Logical folder structure
- Consistent naming
- Proper documentation

### State Management
- Use Provider
- Keep state minimal
- Notify listeners appropriately
- Handle loading states

### Error Handling
- Try-catch blocks
- User-friendly messages
- Log errors for debugging
- Graceful degradation

### UI/UX
- Consistent design
- Loading indicators
- Error states
- Empty states
- Accessibility

---

This structure provides a solid foundation for a professional medical app. All components are modular, tested, and ready for production deployment.
