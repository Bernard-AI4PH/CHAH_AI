# API Setup Guide

## Connecting Flutter App to Your Backend

This guide will help you connect the Flutter mobile app to your existing Flask backend.

## Quick Start

### Step 1: Find Your Computer's IP Address

#### Windows
```cmd
ipconfig
```
Look for "IPv4 Address" under your active network adapter (e.g., 192.168.1.100)

#### macOS/Linux
```bash
ifconfig
```
Or
```bash
hostname -I
```
Look for your local IP address (e.g., 192.168.1.100)

### Step 2: Update Flutter App Configuration

Edit `lib/utils/constants.dart`:

```dart
class ApiConfig {
  // Choose the appropriate URL based on your testing environment:
  
  // Option 1: Android Emulator (default)
  static const String baseUrl = 'http://10.0.2.2:5000';
  
  // Option 2: iOS Simulator
  // static const String baseUrl = 'http://localhost:5000';
  
  // Option 3: Physical Device (replace with your IP)
  // static const String baseUrl = 'http://192.168.1.100:5000';
  
  // Option 4: Production Server
  // static const String baseUrl = 'https://your-domain.com';
}
```

### Step 3: Start Your Flask Backend

Make sure your Flask backend is running and accessible:

```bash
python app.py
```

Your backend should start on `http://localhost:5000` or the port specified in your code.

### Step 4: Test the Connection

1. Open the Flutter app
2. Enter a patient ID (e.g., P001)
3. Click "Generate Report"
4. The app should connect to your backend and retrieve the PDF

## Testing Different Scenarios

### Scenario 1: Testing on Android Emulator

**Backend**: Running on your computer at `localhost:5000`
**Flutter App Config**: Use `http://10.0.2.2:5000`

Why? Android Emulator uses `10.0.2.2` to refer to the host machine's localhost.

### Scenario 2: Testing on iOS Simulator

**Backend**: Running on your Mac at `localhost:5000`
**Flutter App Config**: Use `http://localhost:5000`

Why? iOS Simulator shares the same network as the host machine.

### Scenario 3: Testing on Physical Device (Same WiFi Network)

**Backend**: Running on your computer
**Flutter App Config**: Use `http://YOUR_COMPUTER_IP:5000`

Steps:
1. Ensure both your computer and phone are on the same WiFi network
2. Find your computer's local IP address (see Step 1)
3. Update the `baseUrl` with your computer's IP
4. Make sure your firewall allows connections on port 5000

Example:
```dart
static const String baseUrl = 'http://192.168.1.100:5000';
```

### Scenario 4: Production Deployment

**Backend**: Deployed on a server (e.g., AWS, Heroku, DigitalOcean)
**Flutter App Config**: Use your production URL with HTTPS

Example:
```dart
static const String baseUrl = 'https://api.chah-care.com';
```

**Important**: 
- Remove `android:usesCleartextTraffic="true"` from AndroidManifest.xml for production
- Use HTTPS only for production
- Implement proper authentication

## Backend Requirements

Your Flask backend must be configured to accept requests from the mobile app:

### Enable CORS (if needed)

Install Flask-CORS:
```bash
pip install flask-cors
```

Update `app.py`:
```python
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
```

Or for specific routes:
```python
from flask_cors import cross_origin

@app.route('/api/report/<patient_id>', methods=['GET'])
@cross_origin()
def api_generate_report(patient_id):
    # ... your existing code
```

### Allow External Connections

When running Flask locally for testing with physical devices:

```python
if __name__ == "__main__":
    # Allow connections from other devices on the network
    app.run(host='0.0.0.0', port=5000, debug=True)
```

**Security Note**: Only use `host='0.0.0.0'` for local testing. For production, use proper deployment methods.

## Firewall Configuration

### Windows Firewall

1. Open Windows Defender Firewall
2. Click "Advanced settings"
3. Click "Inbound Rules" → "New Rule"
4. Select "Port" → Next
5. Enter port 5000 → Next
6. Allow the connection → Next
7. Apply to all profiles → Next
8. Name it "Flask Dev Server" → Finish

### macOS Firewall

```bash
# Allow incoming connections on port 5000
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --add /usr/bin/python3
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --unblock /usr/bin/python3
```

### Linux (UFW)

```bash
sudo ufw allow 5000/tcp
sudo ufw reload
```

## Troubleshooting

### Connection Refused Error

**Problem**: App shows "Unable to connect to server"

**Solutions**:
1. ✅ Verify Flask backend is running
2. ✅ Check you're using the correct IP/URL
3. ✅ Ensure device and computer are on same WiFi
4. ✅ Check firewall isn't blocking connections
5. ✅ For Android Emulator, use `10.0.2.2` not `localhost`

### Timeout Error

**Problem**: Request times out

**Solutions**:
1. ✅ Increase timeout in `constants.dart`:
```dart
static const Duration connectTimeout = Duration(seconds: 60);
static const Duration receiveTimeout = Duration(seconds: 120);
```
2. ✅ Check network speed
3. ✅ Verify backend is responding (test with browser/Postman)

### SSL Certificate Error (Production)

**Problem**: Certificate verification failed

**Solutions**:
1. ✅ Ensure your SSL certificate is valid
2. ✅ Use a certificate from a trusted CA
3. ✅ Don't use self-signed certificates in production

### Patient Not Found Error

**Problem**: API returns 404

**Solutions**:
1. ✅ Verify patient ID exists in your CSV files
2. ✅ Check CSV files are in the correct location
3. ✅ Ensure Flask can access demo.csv and emr.csv

## Testing Your API Endpoint

### Using cURL

```bash
# Test from command line
curl http://localhost:5000/api/report/P001 --output test.pdf
```

### Using Browser

Navigate to:
```
http://localhost:5000/api/report/P001
```

Should download a PDF file.

### Using Postman

1. Create new GET request
2. URL: `http://localhost:5000/api/report/P001`
3. Send request
4. Check response is PDF (application/pdf)

## API Response Format

### Success (200 OK)
- Content-Type: `application/pdf`
- Body: PDF file bytes

### Patient Not Found (404)
```json
{
  "error": "No demographics found for Patient_ID = P001"
}
```

### Server Error (500)
```json
{
  "error": "Unexpected error: [error message]"
}
```

## Production Deployment Checklist

Before deploying to production:

- [ ] Use HTTPS for all API calls
- [ ] Implement proper authentication (JWT, OAuth, etc.)
- [ ] Remove development-only CORS settings
- [ ] Set proper rate limiting
- [ ] Enable request logging
- [ ] Use environment variables for configuration
- [ ] Test with production data
- [ ] Implement error monitoring (Sentry, etc.)
- [ ] Set up proper backup systems
- [ ] Follow HIPAA compliance guidelines
- [ ] Remove `usesCleartextTraffic` from Android manifest

## Environment-Specific Configuration

For managing multiple environments, consider using:

### Option 1: Build Flavors (Recommended)

Create separate configurations for dev, staging, and production.

### Option 2: Environment Variables

Use `flutter_dotenv` package:
```yaml
dependencies:
  flutter_dotenv: ^5.1.0
```

Create `.env` files:
```
API_BASE_URL=http://localhost:5000
```

### Option 3: Build-time Constants

Pass configuration during build:
```bash
flutter build apk --dart-define=API_URL=https://api.production.com
```

## Need Help?

If you're still having trouble connecting:

1. Check Flutter logs: `flutter logs`
2. Check backend logs in your terminal
3. Verify network connectivity
4. Test API with cURL or Postman first
5. Review the troubleshooting section above
