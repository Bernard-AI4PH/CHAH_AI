import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PatientIdInput extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onSubmit;

  const PatientIdInput({
    super.key,
    required this.controller,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: 'Patient ID',
        hintText: 'e.g., P001',
        prefixIcon: Icon(
          Icons.badge_rounded,
          color: Theme.of(context).colorScheme.primary,
        ),
        suffixIcon: controller.text.isNotEmpty
            ? IconButton(
                icon: const Icon(Icons.clear),
                onPressed: () => controller.clear(),
              )
            : null,
      ),
      textCapitalization: TextCapitalization.characters,
      style: GoogleFonts.inter(
        fontSize: 16,
        fontWeight: FontWeight.w500,
      ),
      onSubmitted: (_) => onSubmit(),
      onChanged: (_) {
        // Trigger rebuild to show/hide clear button
        (context as Element).markNeedsBuild();
      },
    );
  }
}
