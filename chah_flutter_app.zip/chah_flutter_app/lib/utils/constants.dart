class ApiConfig {
  // TODO: Replace with your actual API URL
  // For local testing: 'http://10.0.2.2:5000' for Android Emulator
  // For local testing: 'http://localhost:5000' for iOS Simulator
  // For production: 'https://your-domain.com'
  
  static const String baseUrl = 'http://10.0.2.2:5000';
  
  // API Endpoints
  static const String generateReportEndpoint = '/api/report';
  
  // Build full URL for report generation
  static String getReportUrl(String patientId) {
    return '$baseUrl$generateReportEndpoint/$patientId';
  }
  
  // Timeout durations
  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 60);
  static const Duration sendTimeout = Duration(seconds: 30);
  
  // Headers
  static Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'Accept': 'application/pdf',
  };
}

class AppConstants {
  // App Info
  static const String appName = 'CHAH AI Care';
  static const String appVersion = '1.0.0';
  
  // Colors (matching your Python app)
  static const int brandGreenHex = 0xFF6BA539;
  
  // Sample Patient IDs for testing
  static const List<String> samplePatientIds = [
    'P001',
    'P002',
    'P003',
    'P004',
    'P005',
  ];
  
  // Error Messages
  static const String networkError = 'Network error. Please check your connection.';
  static const String serverError = 'Server error. Please try again later.';
  static const String patientNotFound = 'Patient not found. Please check the ID.';
  static const String genericError = 'An error occurred. Please try again.';
}
