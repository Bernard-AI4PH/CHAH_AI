import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:printing/printing.dart';
import '../services/report_service.dart';

class PdfViewerScreen extends StatelessWidget {
  final String patientId;

  const PdfViewerScreen({
    super.key,
    required this.patientId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Report - $patientId'),
        actions: [
          // Share Button
          IconButton(
            icon: const Icon(Icons.share_rounded),
            tooltip: 'Share',
            onPressed: () async {
              final reportService = Provider.of<ReportService>(
                context,
                listen: false,
              );
              await reportService.sharePdf();
              
              if (context.mounted && reportService.errorMessage != null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(reportService.errorMessage!),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
          ),
          // Save Button
          IconButton(
            icon: const Icon(Icons.download_rounded),
            tooltip: 'Save',
            onPressed: () async {
              final reportService = Provider.of<ReportService>(
                context,
                listen: false,
              );
              final filePath = await reportService.savePdf();
              
              if (context.mounted) {
                if (filePath != null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Saved to: $filePath'),
                      backgroundColor: Colors.green,
                      duration: const Duration(seconds: 3),
                    ),
                  );
                } else if (reportService.errorMessage != null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(reportService.errorMessage!),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
          ),
          // Print Button
          IconButton(
            icon: const Icon(Icons.print_rounded),
            tooltip: 'Print',
            onPressed: () async {
              final reportService = Provider.of<ReportService>(
                context,
                listen: false,
              );
              await reportService.printPdf();
              
              if (context.mounted && reportService.errorMessage != null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(reportService.errorMessage!),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            },
          ),
        ],
      ),
      body: Consumer<ReportService>(
        builder: (context, reportService, child) {
          if (reportService.currentPdfBytes == null) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.error_outline,
                    size: 64,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No PDF available',
                    style: GoogleFonts.inter(
                      fontSize: 18,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              // Action Bar
              Container(
                padding: const EdgeInsets.all(16),
                color: Colors.white,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _ActionButton(
                      icon: Icons.print_rounded,
                      label: 'Print',
                      color: const Color(0xFF6BA539),
                      onPressed: () async {
                        await reportService.printPdf();
                        if (context.mounted && 
                            reportService.errorMessage != null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(reportService.errorMessage!),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      },
                    ),
                    _ActionButton(
                      icon: Icons.download_rounded,
                      label: 'Save',
                      color: Colors.blue,
                      onPressed: () async {
                        final filePath = await reportService.savePdf();
                        if (context.mounted) {
                          if (filePath != null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('Saved successfully'),
                                backgroundColor: Colors.green,
                              ),
                            );
                          } else if (reportService.errorMessage != null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(reportService.errorMessage!),
                                backgroundColor: Colors.red,
                              ),
                            );
                          }
                        }
                      },
                    ),
                    _ActionButton(
                      icon: Icons.share_rounded,
                      label: 'Share',
                      color: Colors.orange,
                      onPressed: () async {
                        await reportService.sharePdf();
                        if (context.mounted && 
                            reportService.errorMessage != null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(reportService.errorMessage!),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              
              // PDF Viewer
              Expanded(
                child: PdfPreview(
                  build: (format) => reportService.currentPdfBytes!,
                  allowPrinting: true,
                  allowSharing: true,
                  canChangePageFormat: false,
                  canChangeOrientation: false,
                  canDebug: false,
                  pdfFileName: 'transition_report_$patientId.pdf',
                ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          final reportService = Provider.of<ReportService>(
            context,
            listen: false,
          );
          reportService.printPdf();
        },
        backgroundColor: const Color(0xFF6BA539),
        icon: const Icon(Icons.print),
        label: const Text('Print Report'),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onPressed;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 4),
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
