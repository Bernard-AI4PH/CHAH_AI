import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/report_service.dart';
import '../utils/constants.dart';
import '../widgets/patient_id_input.dart';
import '../widgets/quick_access_card.dart';
import '../widgets/info_card.dart';
import 'pdf_viewer_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _patientIdController = TextEditingController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _patientIdController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _generateReport(BuildContext context) async {
    final patientId = _patientIdController.text.trim();
    
    if (patientId.isEmpty) {
      _showErrorDialog(context, 'Please enter a Patient ID');
      return;
    }

    final reportService = Provider.of<ReportService>(context, listen: false);
    
    // Show loading dialog
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Generating report...'),
              ],
            ),
          ),
        ),
      ),
    );

    final success = await reportService.generateReport(patientId);
    
    if (!mounted) return;
    Navigator.pop(context); // Close loading dialog

    if (success) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PdfViewerScreen(patientId: patientId),
        ),
      );
    } else {
      _showErrorDialog(
        context,
        reportService.errorMessage ?? AppConstants.genericError,
      );
    }
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.error_outline, color: Colors.red[700]),
            const SizedBox(width: 8),
            const Text('Error'),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _selectSamplePatient(String patientId) {
    _patientIdController.text = patientId;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with Logo
                _buildHeader(),
                const SizedBox(height: 32),

                // Main Card
                _buildMainCard(context),
                const SizedBox(height: 24),

                // Quick Access Section
                _buildQuickAccessSection(),
                const SizedBox(height: 24),

                // Info Cards
                _buildInfoSection(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFF6BA539).withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            Icons.medical_information_rounded,
            size: 32,
            color: const Color(0xFF6BA539),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'CHAH AI Care',
          style: GoogleFonts.inter(
            fontSize: 32,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Transition Report Generator',
          style: GoogleFonts.inter(
            fontSize: 16,
            color: Colors.grey[600],
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildMainCard(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF6BA539).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.description_rounded,
                    color: Color(0xFF6BA539),
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  'Generate Report',
                  style: GoogleFonts.inter(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Enter a Patient ID to generate a comprehensive transition report',
              style: GoogleFonts.inter(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 24),
            
            // Patient ID Input
            PatientIdInput(
              controller: _patientIdController,
              onSubmit: () => _generateReport(context),
            ),
            
            const SizedBox(height: 20),
            
            // Generate Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _generateReport(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6BA539),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  elevation: 2,
                ),
                icon: const Icon(Icons.file_download_outlined),
                label: const Text('Generate Report'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAccessSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Access',
          style: GoogleFonts.inter(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'Sample Patient IDs for testing',
          style: GoogleFonts.inter(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: AppConstants.samplePatientIds.map((id) {
            return QuickAccessCard(
              patientId: id,
              onTap: () => _selectSamplePatient(id),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildInfoSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'About',
          style: GoogleFonts.inter(
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 16),
        InfoCard(
          icon: Icons.healing_rounded,
          title: 'Comprehensive Care',
          description: 'Generate detailed medical transition reports with AI-powered insights',
          color: Colors.blue,
        ),
        const SizedBox(height: 12),
        InfoCard(
          icon: Icons.security_rounded,
          title: 'Secure & Compliant',
          description: 'HIPAA-compliant data handling and secure report generation',
          color: Colors.green,
        ),
        const SizedBox(height: 12),
        InfoCard(
          icon: Icons.speed_rounded,
          title: 'Real-time Analytics',
          description: '24/7 monitoring with continuous health analytics and risk assessment',
          color: Colors.orange,
        ),
      ],
    );
  }
}
