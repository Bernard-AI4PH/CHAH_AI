import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';

class ReportService extends ChangeNotifier {
  final Dio _dio = Dio(
    BaseOptions(
      baseUrl: ApiConfig.baseUrl,
      connectTimeout: ApiConfig.connectTimeout,
      receiveTimeout: ApiConfig.receiveTimeout,
      sendTimeout: ApiConfig.sendTimeout,
      headers: ApiConfig.headers,
      responseType: ResponseType.bytes,
    ),
  );

  bool _isLoading = false;
  String? _errorMessage;
  Uint8List? _currentPdfBytes;
  String? _currentPatientId;

  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  Uint8List? get currentPdfBytes => _currentPdfBytes;
  String? get currentPatientId => _currentPatientId;

  /// Generate report from API
  Future<bool> generateReport(String patientId) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _dio.get(
        ApiConfig.getReportUrl(patientId),
        options: Options(
          responseType: ResponseType.bytes,
          followRedirects: false,
          validateStatus: (status) => status! < 500,
        ),
      );

      if (response.statusCode == 200) {
        _currentPdfBytes = Uint8List.fromList(response.data);
        _currentPatientId = patientId;
        _isLoading = false;
        notifyListeners();
        return true;
      } else if (response.statusCode == 404) {
        _errorMessage = AppConstants.patientNotFound;
        _isLoading = false;
        notifyListeners();
        return false;
      } else {
        _errorMessage = AppConstants.serverError;
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout ||
          e.type == DioExceptionType.receiveTimeout ||
          e.type == DioExceptionType.sendTimeout) {
        _errorMessage = 'Request timeout. Please try again.';
      } else if (e.type == DioExceptionType.connectionError) {
        _errorMessage = AppConstants.networkError;
      } else {
        _errorMessage = AppConstants.genericError;
      }
      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      _errorMessage = AppConstants.genericError;
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Print the current PDF
  Future<void> printPdf() async {
    if (_currentPdfBytes == null) {
      _errorMessage = 'No PDF available to print';
      notifyListeners();
      return;
    }

    try {
      await Printing.layoutPdf(
        onLayout: (format) async => _currentPdfBytes!,
        name: 'transition_report_$_currentPatientId.pdf',
      );
    } catch (e) {
      _errorMessage = 'Failed to print PDF: $e';
      notifyListeners();
    }
  }

  /// Save PDF to device
  Future<String?> savePdf() async {
    if (_currentPdfBytes == null) {
      _errorMessage = 'No PDF available to save';
      notifyListeners();
      return null;
    }

    try {
      final directory = await getApplicationDocumentsDirectory();
      final file = File(
        '${directory.path}/transition_report_$_currentPatientId.pdf',
      );
      await file.writeAsBytes(_currentPdfBytes!);
      return file.path;
    } catch (e) {
      _errorMessage = 'Failed to save PDF: $e';
      notifyListeners();
      return null;
    }
  }

  /// Share PDF
  Future<void> sharePdf() async {
    if (_currentPdfBytes == null) {
      _errorMessage = 'No PDF available to share';
      notifyListeners();
      return;
    }

    try {
      final directory = await getTemporaryDirectory();
      final file = File(
        '${directory.path}/transition_report_$_currentPatientId.pdf',
      );
      await file.writeAsBytes(_currentPdfBytes!);
      
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'Transition Report - $_currentPatientId',
        text: 'CHAH AI Care Transition Report',
      );
    } catch (e) {
      _errorMessage = 'Failed to share PDF: $e';
      notifyListeners();
    }
  }

  /// Clear current PDF and error
  void clearReport() {
    _currentPdfBytes = null;
    _currentPatientId = null;
    _errorMessage = null;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
