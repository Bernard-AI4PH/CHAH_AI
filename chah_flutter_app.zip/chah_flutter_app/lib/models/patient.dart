class Patient {
  final String patientId;
  final String name;
  final String dob;
  final String sex;
  final String raceEthnicity;
  final String address;
  final String city;
  final String state;
  final String zip;
  final String guardianName;
  final String insuranceType;

  Patient({
    required this.patientId,
    required this.name,
    required this.dob,
    required this.sex,
    required this.raceEthnicity,
    required this.address,
    required this.city,
    required this.state,
    required this.zip,
    required this.guardianName,
    required this.insuranceType,
  });

  factory Patient.fromJson(Map<String, dynamic> json) {
    return Patient(
      patientId: json['Patient_ID'] ?? '',
      name: json['Name'] ?? '',
      dob: json['DOB'] ?? '',
      sex: json['Sex'] ?? '',
      raceEthnicity: json['Race_Ethnicity'] ?? '',
      address: json['Address'] ?? '',
      city: json['City'] ?? '',
      state: json['State'] ?? '',
      zip: json['ZIP'] ?? '',
      guardianName: json['Guardian_Name'] ?? '',
      insuranceType: json['Insurance_Type'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'Patient_ID': patientId,
      'Name': name,
      'DOB': dob,
      'Sex': sex,
      'Race_Ethnicity': raceEthnicity,
      'Address': address,
      'City': city,
      'State': state,
      'ZIP': zip,
      'Guardian_Name': guardianName,
      'Insurance_Type': insuranceType,
    };
  }

  String get fullAddress => '$address, $city, $state $zip';
}
