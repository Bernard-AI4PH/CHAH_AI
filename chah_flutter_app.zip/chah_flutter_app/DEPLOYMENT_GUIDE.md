# Deployment Guide - CHAH Flutter App

Complete guide for deploying the CHAH AI Care Flutter app to production.

## Table of Contents
1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Backend Deployment](#backend-deployment)
3. [Android Deployment](#android-deployment)
4. [iOS Deployment](#ios-deployment)
5. [Post-Deployment](#post-deployment)

---

## Pre-Deployment Checklist

### Code Review
- [ ] All features tested and working
- [ ] No console.log or debug statements
- [ ] Error handling implemented everywhere
- [ ] Loading states implemented
- [ ] No hardcoded sensitive data
- [ ] Comments and documentation updated
- [ ] Code follows style guidelines

### Configuration
- [ ] Production API URL configured
- [ ] HTTPS enabled for all endpoints
- [ ] Environment variables set up
- [ ] API keys secured
- [ ] Remove development/test code
- [ ] Update app version number

### Testing
- [ ] All tests in TESTING_CHECKLIST.md passed
- [ ] Tested on multiple devices
- [ ] Tested on minimum supported OS versions
- [ ] Performance tested with real data
- [ ] Security audit completed

### Legal & Compliance
- [ ] Privacy policy updated
- [ ] Terms of service ready
- [ ] HIPAA compliance verified
- [ ] Required permissions documented
- [ ] Data handling procedures documented

---

## Backend Deployment

### 1. Choose Hosting Provider

**Recommended Options:**
- **AWS EC2** - Full control, scalable
- **Heroku** - Easy deployment, less control
- **DigitalOcean** - Good balance
- **Google Cloud Platform** - Robust infrastructure
- **Azure** - Enterprise features

### 2. Deploy Flask Backend

#### Using AWS EC2 (Detailed Example)

**Step 1: Launch EC2 Instance**
```bash
# Choose Ubuntu 22.04 LTS
# Instance type: t2.small or larger
# Configure security group:
#   - SSH (port 22) - Your IP only
#   - HTTP (port 80) - Anywhere
#   - HTTPS (port 443) - Anywhere
```

**Step 2: Connect and Setup**
```bash
ssh -i your-key.pem ubuntu@your-ec2-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and dependencies
sudo apt install python3-pip python3-venv nginx -y

# Create application directory
mkdir ~/chah-backend
cd ~/chah-backend
```

**Step 3: Upload Application**
```bash
# From your local machine
scp -i your-key.pem -r app.py engine.py demo.csv emr.csv favicon.png requirements.txt ubuntu@your-ec2-ip:~/chah-backend/
```

**Step 4: Setup Python Environment**
```bash
cd ~/chah-backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn
```

**Step 5: Test Application**
```bash
python app.py
# Test in browser: http://your-ec2-ip:5000
```

**Step 6: Configure Gunicorn**

Create `gunicorn_config.py`:
```python
bind = "0.0.0.0:8000"
workers = 4
accesslog = "/var/log/gunicorn/access.log"
errorlog = "/var/log/gunicorn/error.log"
```

**Step 7: Setup Systemd Service**

Create `/etc/systemd/system/chah-backend.service`:
```ini
[Unit]
Description=CHAH Backend
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/chah-backend
Environment="PATH=/home/ubuntu/chah-backend/venv/bin"
ExecStart=/home/ubuntu/chah-backend/venv/bin/gunicorn -c gunicorn_config.py app:app

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable chah-backend
sudo systemctl start chah-backend
sudo systemctl status chah-backend
```

**Step 8: Configure Nginx**

Create `/etc/nginx/sites-available/chah-backend`:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/chah-backend /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

**Step 9: Setup SSL with Let's Encrypt**
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d your-domain.com
sudo systemctl restart nginx
```

### 3. Update Flutter App

Edit `lib/utils/constants.dart`:
```dart
static const String baseUrl = 'https://your-domain.com';
```

---

## Android Deployment

### 1. Prepare for Release

**Update App Configuration**

`android/app/build.gradle`:
```gradle
android {
    defaultConfig {
        applicationId "com.chah.aicare"
        minSdk 21
        targetSdk 34
        versionCode 1  // Increment for each release
        versionName "1.0.0"  // Update version
    }
}
```

**Remove Development Settings**

In `android/app/src/main/AndroidManifest.xml`:
```xml
<!-- Remove for production -->
<!-- android:usesCleartextTraffic="true" -->
```

### 2. Generate Signing Key

```bash
keytool -genkey -v -keystore ~/chah-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias chah
```

**Save credentials securely!**

### 3. Configure Signing

Create `android/key.properties`:
```properties
storePassword=YOUR_KEYSTORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=chah
storeFile=/path/to/chah-release-key.jks
```

Add to `.gitignore`:
```
android/key.properties
```

Update `android/app/build.gradle`:
```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

### 4. Build Release APK

```bash
flutter clean
flutter build apk --release
```

**Output**: `build/app/outputs/flutter-apk/app-release.apk`

### 5. Build App Bundle (for Play Store)

```bash
flutter build appbundle --release
```

**Output**: `build/app/outputs/bundle/release/app-release.aab`

### 6. Test Release Build

```bash
flutter install --release
```

### 7. Google Play Console Deployment

**Preparation:**
1. Create Google Play Developer account ($25 one-time fee)
2. Prepare store listing:
   - App name
   - Short description (80 chars)
   - Full description (4000 chars)
   - Screenshots (phone, 7-inch tablet, 10-inch tablet)
   - Feature graphic (1024 x 500)
   - App icon (512 x 512)
   - Privacy policy URL

**Upload:**
1. Go to Google Play Console
2. Create new application
3. Complete store listing
4. Upload app bundle (app-release.aab)
5. Set up pricing and distribution
6. Submit for review

**Review Process:**
- Usually takes 1-3 days
- May request additional information
- Follow Play Store policies

---

## iOS Deployment

### 1. Prerequisites

- macOS computer
- Xcode installed
- Apple Developer account ($99/year)

### 2. Configure Xcode Project

```bash
open ios/Runner.xcworkspace
```

**Set Bundle Identifier:**
- Select Runner project
- Change Bundle Identifier: `com.chah.aicare`

**Set Version:**
- Version: 1.0.0
- Build: 1

**Configure Signing:**
- Select your team
- Enable "Automatically manage signing"

### 3. Update Info.plist

`ios/Runner/Info.plist`:
```xml
<key>NSPhotoLibraryUsageDescription</key>
<string>We need access to save reports</string>
<key>NSCameraUsageDescription</key>
<string>Not used by the app</string>
```

### 4. Build for iOS

```bash
flutter clean
flutter build ios --release
```

### 5. Archive in Xcode

1. Open Xcode
2. Select "Any iOS Device" or connected device
3. Product → Archive
4. Wait for archive to complete

### 6. Distribute to App Store

1. In Archives window, click "Distribute App"
2. Select "App Store Connect"
3. Choose distribution options
4. Sign and upload

### 7. App Store Connect

**Create App:**
1. Login to App Store Connect
2. My Apps → + → New App
3. Fill in app information

**Prepare for Submission:**
- App name
- Subtitle
- Privacy policy URL
- Description
- Keywords
- Screenshots (all required sizes)
- App icon
- Support URL
- Marketing URL (optional)

**Submit:**
1. Select build from TestFlight
2. Complete all required fields
3. Submit for review

**Review Process:**
- Usually 1-2 days
- May request additional information
- Follow App Store guidelines

---

## Post-Deployment

### 1. Monitor Performance

**Set up monitoring:**
- Firebase Crashlytics
- Sentry for error tracking
- Google Analytics for usage

### 2. User Feedback

**Channels:**
- App store reviews
- In-app feedback form
- Support email
- Social media

### 3. Update Strategy

**When to update:**
- Critical bugs: Immediate
- Security issues: Within 24 hours
- Feature updates: Monthly/quarterly
- Minor bugs: Next regular update

### 4. Version Management

**Semantic Versioning:**
- Major: Breaking changes (2.0.0)
- Minor: New features (1.1.0)
- Patch: Bug fixes (1.0.1)

### 5. Maintenance

**Regular tasks:**
- Monitor crash reports
- Review user feedback
- Update dependencies
- Security patches
- Performance optimization

### 6. Analytics

**Track:**
- Daily active users
- Report generation success rate
- Average session duration
- Most common patient IDs
- Error rates
- API response times

---

## Rollback Procedure

If critical issues found after deployment:

### Android
1. Go to Google Play Console
2. Release Management → App Releases
3. Create new release with previous version
4. Or halt rollout if in staged rollout

### iOS
1. Go to App Store Connect
2. Remove app from sale temporarily
3. Submit new version with fix
4. Or roll back to previous version

---

## Security Best Practices

### Production Environment
- [ ] Use HTTPS only
- [ ] Implement proper authentication
- [ ] Use secure API keys
- [ ] Enable certificate pinning
- [ ] Implement rate limiting
- [ ] Log security events
- [ ] Regular security audits

### Data Protection
- [ ] Encrypt sensitive data
- [ ] Follow HIPAA guidelines
- [ ] Secure data in transit
- [ ] Secure data at rest
- [ ] Regular backups
- [ ] Access controls
- [ ] Audit trails

---

## Support & Maintenance

### Setup Support Channels
- Support email: support@chah-care.com
- Documentation site
- FAQ section
- Bug reporting system
- Feature request system

### Maintenance Schedule
- **Daily**: Monitor errors and crashes
- **Weekly**: Review analytics and feedback
- **Monthly**: Dependency updates
- **Quarterly**: Feature updates
- **Annually**: Major version updates

---

## Emergency Contacts

Document key contacts:
- **Development Team**: [emails]
- **Backend Admin**: [contact]
- **Database Admin**: [contact]
- **Security Team**: [contact]
- **Legal/Compliance**: [contact]

---

## Compliance Documentation

Maintain records of:
- Privacy impact assessments
- Security audits
- HIPAA compliance documentation
- Incident response procedures
- Data retention policies
- Disaster recovery plans

---

## Success Metrics

Track these KPIs:
- App store rating (target: 4.0+)
- Crash-free rate (target: 99.5%+)
- API success rate (target: 99%+)
- Average load time (target: <3s)
- User retention rate
- Report generation success rate

---

**Deployment Checklist Sign-Off**

- [ ] All pre-deployment checks completed
- [ ] Backend deployed and tested
- [ ] Android app built and tested
- [ ] iOS app built and tested (if applicable)
- [ ] Store listings complete
- [ ] Monitoring configured
- [ ] Support channels ready
- [ ] Documentation updated
- [ ] Team trained on support procedures
- [ ] Ready for launch

**Deployed by**: ___________________  
**Date**: ___________________  
**Version**: ___________________
