# Quick Start Guide - CHAH Flutter App

Get up and running in 5 minutes!

## Prerequisites Checklist

- [ ] Flutter SDK installed (https://docs.flutter.dev/get-started/install)
- [ ] Android Studio or Xcode installed
- [ ] Python Flask backend ready
- [ ] Device/Emulator ready to test

## 5-Minute Setup

### 1️⃣ Install Dependencies (1 minute)

```bash
cd chah_flutter_app
flutter pub get
```

### 2️⃣ Configure API URL (1 minute)

Open `lib/utils/constants.dart` and set your backend URL:

```dart
// For Android Emulator
static const String baseUrl = 'http://10.0.2.2:5000';

// For iOS Simulator  
// static const String baseUrl = 'http://localhost:5000';

// For Physical Device (replace with your IP)
// static const String baseUrl = 'http://192.168.1.100:5000';
```

### 3️⃣ Start Your Backend (1 minute)

```bash
# In your backend directory
python app.py
```

### 4️⃣ Run the App (2 minutes)

```bash
# Make sure a device/emulator is connected
flutter devices

# Run the app
flutter run
```

## First Test

1. Open the app
2. Enter patient ID: **P001**
3. Click "Generate Report"
4. View the PDF report

✅ Success! Your app is working.

## Quick Troubleshooting

### Can't connect to backend?

**Android Emulator**: Use `http://10.0.2.2:5000` (not localhost)

**iOS Simulator**: Use `http://localhost:5000`

**Physical Device**: 
- Use your computer's IP (e.g., `http://192.168.1.100:5000`)
- Ensure both are on same WiFi
- Check firewall allows port 5000

### Patient not found?

- Verify Flask backend is running
- Check demo.csv and emr.csv are in backend directory
- Try patient IDs: P001, P002, P003, P004, P005

### Build errors?

```bash
flutter clean
flutter pub get
flutter run
```

## Next Steps

📖 Read [README.md](README.md) for full documentation

🔧 Check [API_SETUP_GUIDE.md](API_SETUP_GUIDE.md) for detailed API configuration

🏗️ Ready to customize? Start with `lib/utils/constants.dart` for colors and branding

## Common Commands

```bash
# Run app
flutter run

# Build APK
flutter build apk --release

# Check Flutter setup
flutter doctor

# Clean build files
flutter clean

# View logs
flutter logs
```

## Sample Patient IDs

Quick access buttons are available for:
- P001 - Alex Morgan
- P002 - Jamie Lee
- P003 - Taylor Young
- P004 - Riley Smith
- P005 - Jordan Cruz

## Support

Having issues? Check these resources:

1. **Connection Issues**: See API_SETUP_GUIDE.md
2. **Build Issues**: Run `flutter doctor` to diagnose
3. **Backend Issues**: Check Flask terminal for errors
4. **General Help**: See README.md

## Production Deployment

When ready for production:

1. Update API URL to production endpoint
2. Remove `android:usesCleartextTraffic="true"` from AndroidManifest
3. Use HTTPS only
4. Build release version: `flutter build apk --release`
5. Test thoroughly before deployment

---

**Need more help?** See the full README.md or API_SETUP_GUIDE.md
