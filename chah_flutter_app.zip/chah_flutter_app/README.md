# CHAH AI Care - Flutter Mobile App

A modern, professional Flutter application for generating and managing medical transition reports through the CHAH AI Care system.

## Features

- 🏥 **Medical Report Generation**: Generate comprehensive transition reports for patients
- 📱 **Modern UI**: Clean, professional medical interface with smooth animations
- 📄 **PDF Viewer**: Built-in PDF viewer with zoom and navigation controls
- 🖨️ **Print Support**: Direct printing functionality for reports
- 💾 **Save & Share**: Save reports to device and share via various platforms
- 🔐 **Secure**: HIPAA-compliant approach to data handling
- 🎨 **Customizable**: Easy to customize branding and colors

## Screenshots

The app features:
- Modern home screen with Patient ID input
- Quick access to sample patients
- Comprehensive PDF viewer
- Print, save, and share functionality
- Professional medical-grade UI design

## Prerequisites

- Flutter SDK (3.0.0 or higher)
- Dart SDK (3.0.0 or higher)
- Android Studio / Xcode (for mobile deployment)
- Python Flask backend running (see Backend Setup)

## Installation

### 1. Install Flutter

Follow the official Flutter installation guide:
https://docs.flutter.dev/get-started/install

### 2. Clone/Extract the Project

```bash
cd chah_flutter_app
```

### 3. Install Dependencies

```bash
flutter pub get
```

## Backend Setup

### Configure API URL

Edit `lib/utils/constants.dart` and update the `baseUrl`:

```dart
class ApiConfig {
  // For Android Emulator (connects to localhost on your computer)
  static const String baseUrl = 'http://10.0.2.2:5000';
  
  // For iOS Simulator
  // static const String baseUrl = 'http://localhost:5000';
  
  // For Physical Device (use your computer's IP)
  // static const String baseUrl = 'http://192.168.1.100:5000';
  
  // For Production
  // static const String baseUrl = 'https://your-domain.com';
}
```

### Start Your Flask Backend

```bash
# Make sure your Python backend is running
python app.py
```

The Flask app should be accessible at `http://localhost:5000`

## Running the App

### Android Emulator

```bash
# Start an Android emulator first, then:
flutter run
```

### iOS Simulator (macOS only)

```bash
# Start iOS simulator first, then:
flutter run
```

### Physical Device

1. Enable USB debugging on your Android device
2. Connect device via USB
3. Run:
```bash
flutter run
```

## Building for Production

### Android APK

```bash
flutter build apk --release
```

The APK will be at: `build/app/outputs/flutter-apk/app-release.apk`

### Android App Bundle (for Play Store)

```bash
flutter build appbundle --release
```

### iOS (macOS only)

```bash
flutter build ios --release
```

## Project Structure

```
lib/
├── main.dart                 # App entry point
├── models/
│   └── patient.dart         # Patient data model
├── screens/
│   ├── home_screen.dart     # Main screen with patient ID input
│   └── pdf_viewer_screen.dart # PDF viewing and actions
├── services/
│   └── report_service.dart  # API communication & PDF handling
├── utils/
│   └── constants.dart       # App constants and API config
└── widgets/
    ├── patient_id_input.dart    # Custom input widget
    ├── quick_access_card.dart   # Quick patient selection
    └── info_card.dart           # Information display card
```

## API Integration

The app connects to your Flask backend through the following endpoint:

```
GET /api/report/{patient_id}
```

**Response**: PDF file (application/pdf)

### Error Handling

The app handles the following error cases:
- Network connectivity issues
- Server errors (500)
- Patient not found (404)
- Request timeouts
- Invalid responses

## Customization

### Branding Colors

Edit `lib/main.dart` to customize colors:

```dart
colorScheme: ColorScheme.fromSeed(
  seedColor: const Color(0xFF6BA539), // Your brand color
  primary: const Color(0xFF6BA539),
  secondary: const Color(0xFF4A7C2F),
),
```

### App Name & Logo

1. Update app name in `pubspec.yaml`
2. Replace logo: Add your logo to `assets/images/logo.png`
3. Update app icon using `flutter_launcher_icons` package

## Testing

### Sample Patient IDs

The app includes quick access buttons for sample patients:
- P001
- P002
- P003
- P004
- P005

These IDs are defined in `lib/utils/constants.dart`

### Testing Checklist

- [ ] Patient ID input validation
- [ ] Report generation with valid ID
- [ ] Error handling with invalid ID
- [ ] PDF viewing and navigation
- [ ] Print functionality
- [ ] Save to device
- [ ] Share functionality
- [ ] Network error handling
- [ ] UI responsiveness on different screen sizes

## Troubleshooting

### "Unable to connect to server"

1. Verify Flask backend is running
2. Check API URL in `constants.dart`
3. For Android Emulator, use `10.0.2.2` instead of `localhost`
4. For Physical Device, use your computer's local IP address
5. Ensure `android:usesCleartextTraffic="true"` is in AndroidManifest.xml

### PDF Not Displaying

1. Check that API is returning valid PDF bytes
2. Verify response content-type is `application/pdf`
3. Check console for error messages

### Print Not Working

1. Ensure device has printing capability
2. Check that printer is connected/configured
3. Try using "Save as PDF" if direct printing fails

## Dependencies

Key packages used:
- `provider` - State management
- `dio` - HTTP client for API calls
- `printing` - PDF viewing and printing
- `google_fonts` - Custom typography
- `share_plus` - Cross-platform sharing
- `path_provider` - File system access

## Security Notes

- Never commit API keys or credentials
- Use environment variables for sensitive configuration
- Implement proper authentication in production
- Enable HTTPS for production API endpoints
- Follow HIPAA compliance guidelines for medical data

## Support

For issues or questions:
1. Check existing issues in the repository
2. Review Flutter documentation: https://docs.flutter.dev
3. Check API backend logs for server-side errors

## License

This project is part of the CHAH AI Care system.

## Version History

- **1.0.0** - Initial release
  - Patient ID input and report generation
  - PDF viewing, printing, and sharing
  - Modern medical UI design
  - Error handling and validation
